#ifndef __DS_CO2_IIC_H
	#define __DS_CO2_IIC_H
	
	#define CO2_IIC_ADDR 0x08
	
	typedef struct {
		uint16_t value;//CO2 ����
        	uint16_t ratio;
        	uint16_t temperature; 
	}CO2_Data;

	extern CO2_Data co2_data;
	void CO2_Init(void);
	void CO2_GetValue(CO2_Data* co2Data);

#endif
