#include "DS_CO2_IIC_example.h"

/*the iic functions should be realized specially*/
#include "iic.h"

/*there is nothing need to config,maybe your  serser power is controllable*/
static void CO2_Power(uint8_t pwr_ctl)
{
	/*need to be realized specially*/
}
/*  initialization of PMS senser */
void CO2_Init(void)
{
	CO2_Power(1);
	iic_init();
}

//simulative iic ,read 32bytes of CO2 output data
static uint8_t CO2_RegRead(uint8* buffer)
{
	 uint8   ByteCount;
//    uint8   time_out;
	
//	if(I2C_Start_Condition() == I2C_BUS_BUSY)
//	{
//		return 1;
//	}
//	if(I2C_WriteByte(CO2_IIC_ADDR<<1) == I2C_REPLY_NACK)
//	{
//		return 1;
//	}
//	if(I2C_WriteByte(0) == I2C_REPLY_NACK)
//	{
//		return 1;
//	}
	if(I2C_Start_Condition() == I2C_BUS_BUSY)
	{
		return 1;
	}
	if(I2C_WriteByte((CO2_IIC_ADDR<<1)|0x01) == I2C_REPLY_NACK)
	{
		return 1;
	}
//	/*clock stretch*/
//	I2C_SCL_H;
//	time_out = 0;
//	while(time_out < 100)
//	{
//		Delayms(1);
//		if(UV_SCL_Read())
//			break;
//		else
//			time_out += 1;
//	}
//	if(time_out == 100)
//		return 1;

	for(ByteCount = 0;ByteCount <	12	;ByteCount++)
	{
		if(ByteCount ==  11  )
			*(RegData+ByteCount) = I2C_ReadByte(I2C_REPLY_NACK);
		else
			*(RegData+ByteCount) = I2C_ReadByte(I2C_REPLY_ACK);
	}
	
	I2C_Stop_Condition();
	return 0;
}
uint8_t CO2_GetValue(CO2_Data *co2)
{
	uint8_t co2_rxdata[12];
	uint16_t checksum=0;
	uint8_t i;
	if(CO2_RegRead(co2_rxdata))
		return 1;
	if(co2_rxdata[0]!= 0x42 || co2_rxdata[1]!= 0x4D){
		flag_receive = 0;
		return;
	}
	for(i=0,i<10;i++)
		checksum	+=	co2_rxdata[i];
	
	if(checksum == co2_rxdata[10]*256+co2_rxdata[11])
	{
		co2->value =    co2_rxdata[4]*256   +   co2_rxdata[5];
                co2->ratio  =   co2_rxdata[6]*256   +   co2_rxdata[7];
                co2->temperature  =   co2_rxdata[8]*256   +   co2_rxdata[9];
		flag_receive = 0;
	}
	return 0;
}






























