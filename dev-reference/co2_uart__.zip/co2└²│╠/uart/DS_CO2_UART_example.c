#include "DS_CO2_UART_example.h"

/*the uart functions should be realized specially*/
#include "uart.h"
typedef enum {
	CO2_STATE_SEND_CMD=0,
	CO2_STATE_WAIT,
	CO2_STATE_GETVALUE,
	CO2_STATE_DELAY
}CO2_State;

/*used for uart receive data,uart data can be received by interrupt or reading 
repeatedly*/
uint8_t co2_rxdata[12];
/*after a complete 
package received,flag_receive is set,it will be cleared at CO2_GetValue()*/
uint8_t flag_receive=0;
CO2_Data co2_data;

/*there is nothing need to config,maybe your  serser power is controllable*/
static void CO2_Power(uint8_t pwr_ctl)
{
	//need to be realized specially
}


/*  initialization of PMS senser */
void CO2_Init(void)
{
	CO2_Power(1);
	uart_init(9600);
}


void CO2_SendCmd(uint8_t cmd,uint16_t para)
{
	uint8 i;
	uint16 checkSum=0;
	uint8 co2Cmd[7];
	co2Cmd[0]='B';
	co2Cmd[1]='M';
	co2Cmd[2]=cmd;
	co2Cmd[3]=param>>8;
	co2Cmd[4]=param;
	
	for(i=0;i<5;i++)
			checkSum	+=	co2Cmd[i];
	co2Cmd[5]=lrcdata>>8;
	co2Cmd[6]=lrcdata; 
	
	uart_send(co2Cmd,7);
}

void CO2_GetValue(CO2_Data* co2)
{
	uint16_t checksum=0,i;
	if(co2_rxdata[0]!= 0x42 || co2_rxdata[1]!= 0x4D){
		flag_receive = 0;
		return;
	}
	for(i=0,i<10;i++)
		checksum	+=	co2_rxdata[i];
	
	if(checksum == co2_rxdata[10]*256+co2_rxdata[11])
	{
		co2->value =    co2_rxdata[4]*256   +   co2_rxdata[5];
                co2->ratio  =   co2_rxdata[6]*256   +   co2_rxdata[7];
                co2->temperature  =   co2_rxdata[8]*256   +   co2_rxdata[9];
		flag_receive = 0;
	}
}
/*this function provide a way to read DS-CO2 senser,please put it in the
	main  infinite loop.*/
void CO2_Process(void)
{
	static CO2_State state=CO2_STATE_SEND_CMD;
	static uint32_t rem_ms=0;
	switch(state)
	{
		case CO2_STATE_SEND_CMD:
			CO2_SendCmd(CO2_CMD_READ,0);
			rem_ms	=	0;
			state	=	CO2_STATE_WAIT;
		break;
		case CO2_STATE_WAIT:
			if(flag_receive){
				state	=	CO2_STATE_GETVALUE;
			}else if(rem_ms <500){
				delayms(1);
				rem_ms++;
			}else{
				state	=	CO2_STATE_SEND_CMD;
			}
		break;
		case CO2_STATE_GETVALUE:
			CO2_GetValue(&co2_data);
			rem_ms	=	0;
			state	=	CO2_STATE_DELAY;
		break;
		case CO2_STATE_DELAY:
			if(rem_ms <500){
				delayms(1);
				rem_ms++;
			}else{
				state	=	CO2_STATE_SEND_CMD;
			}
		break;
		default:
			state=CO2_STATE_SEND_CMD;
		break;
		
	}
	
}






